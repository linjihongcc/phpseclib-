<?php
//  echo  set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib'); 
//      require_once('vendor/autoload.php');
//      use phpseclib3\Net\SSH2;
//      $ssh = new SSH2('47.253.81.181'); 
// if (!$ssh->login('root', 'Mu0yF6FzAvrWQ^pV')) { 
// exit('Login Failed'); 


include 'vendor/autoload.php';

$data = [];
function csvArr($file)
{

    global $excel_i, $data;
    $excel_path = __DIR__ . '/NFList/' . $file . '.csv';
    if (!file_exists($excel_path)) {
        echo '未找到列表文件!' .  $excel_path . PHP_EOL;
        die();
    }

    //单个csv读取
    $excel_file = fopen($excel_path, 'r');
    //计数
    $excel_i = -1;
    while (!feof($excel_file)) {
        $excel_row_array = fgetcsv($excel_file);

        //跳过第一行
        if ($excel_i === -1) {
            $excel_i++;
            continue;
        }
        $excel_i++;
        //var_export($excel_row_array);

        //读取报错跳出
        if (false === $excel_row_array) {
            continue;
        }
        //保证每个参数都不能为空
        foreach ($excel_row_array as $excel_row_value) {

            if (isset($excel_row_array[0])) {
                //  var_export($excel_row_array . PHP_EOL);
                //去空格
                $array = array_filter(array_map('trim', $excel_row_array));
                if (empty($array)) {
                    //echo $excel_row_value[0] . '检查表格是否有关键信息没填' . PHP_EOL;
                    continue;
                }
                // var_export($excel_row_array);
                // continue;

                $data[$excel_row_array[0]] = $array;
            } else {

                var_export('出现空行   ' . $excel_i . "|" . $excel_row_array[0] . PHP_EOL);
            }
        }
    }
}
csvArr('NF_DB');


//遍历替换
foreach ($data as $index => $DBS) {
    $ssh = new \phpseclib3\Net\SSH2('196.247.27.194', 55129);

    //登录服务
    if (!$ssh->login('root', 'CR3d42duN$hTV*a6')) {
        exit('Login Failed');
    }
    $domain  = $DBS[0];
    $number  = $DBS[1];
    $db = $DBS[2];
    echo $ssh->exec('pwd');  // echo $ssh->exec('ls -la');
    echo $ssh->exec("echo \"
    UPDATE configuration SET configuration_value = '$number' WHERE configuration.configuration_id = 316;
    \"| mysql -hrm-rj9y4v0x891fhiz9oio.mysql.rds.aliyuncs.com  -P3306 -uroot -pb%C*jkKaJ $db");

    echo $ssh->exec("exit;");
    var_export($db . ' | ' . $domain . ' | ' . $number);
    // warning: here-document at line 0 delimited by end-of-file (wanted `EOF')   EOF结尾不能出现空格
}
