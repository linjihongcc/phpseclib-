<?php

var_export(get_include_path());
die();
set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib/phpseclib');
include('Net/SSH2.php');
include('Net/SFTP.php');

$sftp = new Net_SFTP('SomeServer', 22);
if (!$sftp->login('root', '12345')) { //if you can't log on...
    exit('sftp Login Failed');
}
echo $sftp->pwd();

$output = $sftp->put('/root/1_yum_stuff.sh', '1_yum_stuff.txt');
echo $output;
$output = $sftp->exec('ls -a');
//$output = $sftp->exec('./1_yum_stuff.sh & 1>1.txt');
echo $output;
$output = $sftp->exec('pwd');
echo $output;
echo ("3rd try!");
