<?php
//  echo  set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib'); 
//      require_once('vendor/autoload.php');
//      use phpseclib3\Net\SSH2;
//      $ssh = new SSH2('47.253.81.181'); 
// if (!$ssh->login('root', 'Mu0yF6FzAvrWQ^pV')) { 
// exit('Login Failed'); 


include 'vendor/autoload.php';

//ip列表
$ip_list = file_get_contents('./ip.txt');
$ip_list = explode("\r\n", $ip_list);

//域名列表
$domain_list = file_get_contents('./domain.txt');
$domain_list = explode("\r\n", $domain_list);


//遍历替换
foreach ($ip_list as $index => $ip) {
    $ssh = new \phpseclib3\Net\SSH2($ip);

    //登录服务
    if (!$ssh->login('root', 'Mu0yF6FzAvrWQ^pV')) {
        exit('Login Failed');
    }
    $domain = $domain_list[$index];

    echo $ssh->exec('pwd');  // echo $ssh->exec('ls -la');
    echo $ssh->exec("echo \"
    UPDATE wp_options SET option_value = replace(option_value, 'handsomeanne.com', '$domain');
    UPDATE wp_posts SET guid = replace(guid, 'handsomeanne.com','$domain');
    UPDATE wp_posts SET post_content = replace(post_content, 'handsomeanne.com', '$domain');
    UPDATE wp_postmeta SET meta_value = replace(meta_value,'handsomeanne.com','$domain');
    UPDATE wp_users  SET user_url = replace(user_url,'handsomeanne.com','$domain');
    UPDATE wp_wc_admin_note_actions  SET query = replace(query,'handsomeanne.com','$domain');
    \"| mysql -h localhost  -P3306 -uroot -p1wsx2qaz site");

    echo $ssh->exec("exit;");
    var_export($ip . ' | ' . $domain);
    // warning: here-document at line 0 delimited by end-of-file (wanted `EOF')   EOF结尾不能出现空格
}







   
// echo $ssh->exec('expect <<-EOF #disable command output 
// log_user 0 
// # start the mysqldump process 
// spawn mysql -uroot -p site -e "SHOW TABLES" 
// # wait for the password prompt 
// expect "password:" 
// # send the password (mind the \r) 
// send "1wsx2qaz\r" 
// # enable output again 
// log_user 1 
// # echo all outout until the end 
// expect eof 
// EOF');








//  UPDATE wp_options SET option_value = replace(option_value, 'joanblueshipping.com', '$domain');
// UPDATE wp_posts SET guid = replace(guid, 'handsomeanne.com','$domain');
// UPDATE wp_posts SET post_content = replace(post_content, 'handsomeanne.com', '$domain');
// UPDATE wp_postmeta SET meta_value = replace(meta_value,'handsomeanne.com','$domain');
// UPDATE wp_users  SET user_url = replace(user_url,'handsomeanne.com','$domain');
// UPDATE wp_wc_admin_note_actions  SET query = replace(query,'handsomeanne.com','$domain');








//    $ssh = new \phpseclib3\Net\SSH2('47.253.81.181');

//    if (!$ssh->login('root', 'Mu0yF6FzAvrWQ^pV')) {
//        exit('Login Failed');
//    }

//    echo $ssh->exec('pwd');  // echo $ssh->exec('ls -la');

//    echo $ssh->exec('echo "
//    select * from wp_users;
//    select * from wp_usermeta;
   
//    " | mysql  -P3306 -uroot -p1wsx2qaz site'); 



//    $sftp = new \phpseclib3\Net\SFTP('47.253.81.181');
//       if (!$sftp->login('root', 'Mu0yF6FzAvrWQ^pV')) {
//           exit('Login Failed');
//       }
  

//       echo $sftp->pwd() . "\r\n";
